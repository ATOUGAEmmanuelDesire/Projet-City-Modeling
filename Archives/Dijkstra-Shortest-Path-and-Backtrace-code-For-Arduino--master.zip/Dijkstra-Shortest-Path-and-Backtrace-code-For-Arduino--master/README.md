# Dijkstra-Shortest-Path-and-Backtrace-code-For-Arduino
This is the implementation of the shortest path with backtrace to get the nodes and to give directions (NORTH, WEST,...), implemented with C++ and for Arduino (No STL used)

### The size of the graph, the weight of the edges and almost all parameters can be modified.
No C++ STL library functions are used so users can import code directly without need of downloading/updating a library.
