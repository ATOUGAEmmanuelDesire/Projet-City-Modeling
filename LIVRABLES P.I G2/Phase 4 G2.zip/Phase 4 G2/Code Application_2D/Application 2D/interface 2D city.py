# Appel des bibliothèques tkinter, pygame et serial
from tkinter import *
import pygame
import serial





#fonction qui renferme l'interface 2D
def interface_2d():
    pygame.init()


    
    class Barriere(pygame.sprite.Sprite):
        
        def __init__(self):
            super().__init__()
            self.velocity = 5
            self.image = pygame.image.load('barriere.png')
            self.rect = self.image.get_rect()
            
        
            
    
    #création de la classe gestion qui gere l'interface 2D en général
    class Gestion:
        
        def __init__(self):
            
            self.voiture = Voiture()
            self.pressed = {}
            

    #création de la classe voiture qui gere le controle ,la vitesse de la voiture 
    class Voiture(pygame.sprite.Sprite):
        
        def __init__(self):
            super().__init__()
            self.velocity = 5
            self.image = pygame.image.load('voiture (2).png')
            self.rect = self.image.get_rect()
            self.rect.x = 90
            self.rect.y = 450

        def droite(self):
            self.rect.x += self.velocity

        def gauche(self):
            self.rect.x -= self.velocity

        def haut(self):
            self.rect.y -= self.velocity

        def bas(self):
            self.rect.y += self.velocity
        

    # utilisation du module pygame pour définir la résolution de l'écran et le nom de la page de l'interface_2d
    pygame.display.set_caption("INTERFACE 2D","smart.ico")
    screen = pygame.display.set_mode((800,594))
    
    background = pygame.image.load('arriereko.png')
    
    #creation de l'instance gestion pour appeler la classe Gestion
    gestion = Gestion()
    
    running = True
    # Boucle qui permet de maintenir activer notre interface 2D
    while running:
        
        screen.blit(background, (0,0))
        
        screen.blit(gestion.voiture.image, gestion.voiture.rect)

        if gestion.pressed.get(pygame.K_RIGHT):
            gestion.voiture.droite()
        elif gestion.pressed.get(pygame.K_LEFT):
            gestion.voiture.gauche()
        elif gestion.pressed.get(pygame.K_UP):
            gestion.voiture.haut()
        elif gestion.pressed.get(pygame.K_DOWN):
            gestion.voiture.bas()
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                gestion.pressed[event.key] = True
            elif event.type == pygame.KEYUP:
                gestion.pressed[event.key] = False
                    
                    
                    
    
    
# Création de la fenetre CITY SMART ROAD
fenetre = Tk()

# Définition de la résolution de la couleur d'arrière plan de l'interface
fenetre.geometry("1080x720")
fenetre.title("INTERFACE CITY SMART ROAD")
fenetre['bg'] = 'white'


# Définition du titre de l'interface CITY et inclusion du logo
label = Label(fenetre, text="INTERFACE CITY SMART ROAD", font = ("Arial", 40, "italic bold"), fg="black", bg="white")
label.pack()
photo = PhotoImage(file='city.png')
image= Label(fenetre, image=photo)
image.pack()

# Création du bouton vers l'interface 2D et son positionnement
bouton = Button(fenetre, text="Lancer l'interface graphique 2D", bg= 'white',fg='black', command=interface_2d)
bouton.place(x='',y='700')

# Création du texte d'introduction
texte = """
Bienvenue sur City Smart Road !

Nous vous offrons une expérience de conduite intelligente et sécurisée pour naviguer dans les rues de notre ville. Notre système avancé utilise des technologies de pointe pour optimiser votre trajet et vous fournir des informations en temps réel.

- Itinéraires optimisés : Notre algorithme intelligent analyse les conditions de circulation en temps réel pour vous proposer les meilleurs itinéraires, en évitant les embouteillages et en minimisant les temps de trajet.

- Alertes de sécurité : Soyez informé des conditions dangereuses sur la route, telles que les accidents, les travaux routiers ou les conditions météorologiques défavorables. Notre système vous avertira afin que vous puissiez prendre les précautions nécessaires.

- Points d'intérêt : Découvrez les lieux intéressants à proximité de votre trajet, tels que les restaurants, les stations-service, les hôpitaux et bien plus encore. Vous pouvez planifier des arrêts pratiques en cours de route.

- Assistance vocale : Notre interface conviviale vous guide tout au long de votre voyage avec des instructions vocales claires. Vous pouvez vous concentrer sur la route tout en restant informé de votre parcours.

Profitez d'une conduite fluide et sécurisée avec City Smart Road ! N'hésitez pas à explorer toutes les fonctionnalités disponibles et à nous faire part de vos commentaires pour continuer à améliorer votre expérience de conduite.
"""
text_widget = Text(fenetre, width=80, height=12, font=("Verdana", 20))
text_widget.insert(END, texte)
text_widget.place(relx=0.5, rely=0.5, anchor= CENTER)

# Boucle de maintien de l'interface CITY SMART ROAD
fenetre.mainloop()
