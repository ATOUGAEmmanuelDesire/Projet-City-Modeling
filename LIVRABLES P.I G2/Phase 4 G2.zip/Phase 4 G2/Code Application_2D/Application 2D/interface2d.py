import pygame
import pyfirmata
pygame.init()



class Voiture(pygame.sprite.Sprite):
    
    def __init__(self):
        super().__init__()
        self.velocity = 5
        self.voiture = pygame.image.load('voiture (2).png')
        self.rect = self.voiture.get_rect()
        self.rect.x = 90
        self.rect.y = 450
        
    
        

pygame.display.set_caption("INTERFACE 2D CITY SMART ROAD")
screen = pygame.display.set_mode((800,594))

backgroung = pygame.image.load('arriereko.png')
running = True

voiture1= Voiture()

while running:
    
    screen.blit(backgroung, (0, 0))
    screen.blit(voiture1.voiture,voiture1.rect )
    pygame.display.flip()
    for event in pygame.event.get():
       if event.type == pygame.QUIT:
           running = False
           pygame.quit()
           print("Fermeture de l'interface 2D")
